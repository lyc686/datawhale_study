from torchcam import methods, metrics, utils

try:
    from .version import __version__  # noqa: F401
except ImportError:
    pass
